# Hotel-Room-Booking-System
It is A Hotel Room Booking Website developed using Django Framework

<b>Features For Normal Users</b>
<ul>
  <li>Separate Login and Signup page</li>
  <li> Can check Availability of Rooms for Specific date and Location</li>
  <li>Can Book Rooms</li>
  <li>Can see all their Bookings in the <b><i>"My Bookings"</i></b></li>
</ul>

<b>Features For Staff User</b>
<ul>
  <li>Separate Login and Signup page</li>
  <li> Can check Availability of Rooms for Specific date and Location</li>
  <li>Can Book Rooms</li>
  <li>See the stats of the Rooms in the <b><i>"Dashboard"<i></b></li>
  <li>Can see the Bookings of all the Users </li>
  <li>Can See/Modify the details of the rooms</li>
  <li>Can Add New Rooms</li>
  <li>Can Add New Location</li>
</ul>
<b>See the Demonstration of this project</b><br/>
<a href="http://www.youtube.com/watch?v=XhydAiCgToA">http://www.youtube.com/watch?v=XhydAiCgToA</a>

